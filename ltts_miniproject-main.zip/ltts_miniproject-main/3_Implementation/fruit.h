#ifndef FRUIT_H
#define FRUIT_H

void setup();

#endif