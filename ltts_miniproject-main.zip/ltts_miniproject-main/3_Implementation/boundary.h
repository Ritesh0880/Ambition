#ifndef BOUNDARY_H
#define BOUNDARY_H

void draw();

#endif