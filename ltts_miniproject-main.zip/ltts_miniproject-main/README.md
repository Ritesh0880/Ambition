# Snake Game

1. Entertaining snake game that we used to play on the old nokia phones.
2. Simple motive of the game is to get a high score with not killing the snake as long as possible.
3. Compete with everyone with the highest score you can achieve.

![image](https://media.geeksforgeeks.org/wp-content/uploads/20201231160840/snakegame.jpg)

## Folder Structure
Folder             | Description
-------------------| -----------------------------------------
`1_Requirements`   | Documents detailing requirements and research
`2_Design`         | Documents specifying design details
`3_Implementation` | All code and documentation
`4_Test_plan`      | Documents with test plans and procedures